import torch 
import numpy as np 
'''
这段代码的作用是基于预训练模型的sparse mask，
在训练的过程中生成四个新的随机sparse mask，
分别为rp_5.pt、rp_20.pt、rp_50.pt和rp_70.pt。

首先读取预训练模型的sparse mask（mask_dict），
然后获取所有mask值，
将其展平后生成一个数组all_sequence。
根据比例获得四个需要的百分比排序值的索引
（index5、index20、index50和index70）。
接下来，针对每个key都生成一个随机的new_mask，
通过numpy中的where函数生成一个0-1矩阵。

如果indict_mask（代表每个元素在乘法矩阵中随机获得的一个值）
小于相应索引对应的value，
那么在new_mask上标为0，否则标为1。

最后将四个new_mask储存在对应的文件中。
'''

mask_dict = torch.load('deit_tiny_mask_init/deit_tiny_patch16_224_sparse0.5_after_train.pt')

new_mask5 = {}
new_mask20 = {}
new_mask50 = {}
new_mask70 = {}

indict_mask = {}

all_sequence = []
for key in mask_dict.keys():
    indict_mask[key] = torch.rand_like(mask_dict[key])
    all_sequence.append(indict_mask[key].reshape(-1))

all_sequence = torch.cat(all_sequence, 0)
nelement = all_sequence.shape[0]

sort_args = all_sequence.argsort()
index20 = sort_args[-int(nelement*0.2)]
index5 = sort_args[-int(nelement*0.05)]
index50 = sort_args[-int(nelement*0.5)]
index70 = sort_args[-int(nelement*0.7)]


for key in mask_dict.keys():
    ones = torch.ones_like(mask_dict[key])
    zeros = torch.zeros_like(mask_dict[key])
    new_mask5[key] = torch.where(indict_mask[key]<all_sequence[index5], zeros, ones)
    new_mask20[key] = torch.where(indict_mask[key]<all_sequence[index20], zeros, ones)
    new_mask50[key] = torch.where(indict_mask[key]<all_sequence[index50], zeros, ones)
    new_mask70[key] = torch.where(indict_mask[key]<all_sequence[index70], zeros, ones)

torch.save(new_mask5, 'deit_tiny_mask_init/rp_5.pt')
torch.save(new_mask20, 'deit_tiny_mask_init/rp_20.pt')
torch.save(new_mask50, 'deit_tiny_mask_init/rp_50.pt')
torch.save(new_mask70, 'deit_tiny_mask_init/rp_70.pt')


