import copy 
import torch
import numpy as np
import torch.nn as nn
import torch.nn.utils.prune as prune
from layers import Conv2d, Linear,Attention_Headmask,Attention_sp
from vision_transformer import Attention



def name_qkv_masks(module):
    r"""Returns an iterator over modules masks, yielding the mask.
    """
    for name, buf in module.named_buffers():
        if "qkv_mask" in name:
            yield name,buf
def name_proj_masks(module):
    r"""Returns an iterator over modules masks, yielding the mask.
    """
    for name, buf in module.named_buffers():
        if "proj_mask" in name:
            yield name,buf

def name_proj_module(module):
    r"""Returns an iterator over modules masks, yielding the mask.
    """
    for name, module_child in module.named_children():
        if name == "proj":
            yield name,module_child


def name_proj_masks_with_module(model):
    r"""Returns an iterator over modules masks, yielding the mask.
    """
    for name,module in model.named_modules():
        if isinstance(module, Attention_sp):# 找到head
            print("Attention_sp",name)
            for (nmask,mask),(nchildren,module_child) in zip(name_proj_masks(module),name_proj_module(module)):
                print(nmask,nchildren)
                if " " is not module.proj.bias:
                    #print("nmask",nmask)#head_mask 
                    yield nmask,mask ,module_child     


def weight_list_to_scores(layer, head_size = None):
    #layer 应该是一个linear？ 就是atten里面的proj，等下就给你遍历出来，等着奥
    if 1:
        result_head_level = []
        num_heads = layer.in_features // head_size
        for i in range(num_heads):
            group_weight = layer.weight.data[:,i * head_size : (i + 1) * head_size]
            group_weight = group_weight.reshape(-1)
            result_head_level.append((group_weight ** 2).sum(0))
        return torch.tensor(result_head_level)

class vitheadPruner:
    def __init__(self, model):
        self.name_qkv_masks = list(name_qkv_masks(model))
        self.name_proj_masks = list(name_proj_masks(model))
        self.name_proj_masks_with_module = list(name_proj_masks_with_module(model))
        self.scores = {}
        self.strategy = {}
    def head_proj_mag_score(self,head_size):#, model, loss, dataloader, device
        for i,(name, mask,module_child) in enumerate(self.name_proj_masks_with_module):
            inmae = str(i)+name
            self.scores[inmae] = weight_list_to_scores(module_child, head_size = head_size)
    
    def score_to_list(self):
        for name, score in self.scores.items():
            self.strategy[name] = [0,1,0,0,1,0,1,1,0,0,1,1]

    def mask_by_list(self,head_size):

        print("look")
        for i,(name, mask,module_child) in enumerate(self.name_proj_masks_with_module):
            iname = str(i)+name
            print("mask",iname,mask.size())

            for j,index_inside_layer in enumerate(self.strategy[iname]):
                if index_inside_layer==0:
                    mask.data[:, index_inside_layer * head_size : (index_inside_layer + 1 ) * head_size] = 0

        print("!!!!!!!!!!!!",mask.keys())

            #mask.copy_()
