import copy 
import torch
import numpy as np
import torch.nn as nn
import torch.nn.utils.prune as prune
from layers import Conv2d, Linear

__all__ = ['masked_parameters', 'SynFlow', 'Mag', 'Taylor1ScorerAbs', 'check_sparsity', 'check_sparsity_dict', 
        'prune_model_identity', 'prune_model_custom', 'extract_mask', 'prune_conv_linear']

def masks(module):
    r"""Returns an iterator over modules masks, yielding the mask.
    """
    for name, buf in module.named_buffers():
        if "mask" in name:
            yield buf
def name_masks(module):
    r"""Returns an iterator over modules masks, yielding the mask.
    """
    for name, buf in module.named_buffers():
        if "mask" in name:
            yield name,buf
def masked_parameters(model):
    r"""Returns an iterator over models prunable parameters, yielding both the
    mask and parameter tensors.
    """
    for module in model.modules():
        if isinstance(module, nn.Conv2d) or isinstance(module, nn.Linear):
            for mask, param in zip(masks(module), module.parameters(recurse=False)):
                if param is not module.bias:
                    yield mask, param
from vision_transformer import Attention
from layers import Attention_Headmask,Attention_sp
def masked_head_qkv_parameters(model):
    r"""Returns an iterator over models prunable parameters, yielding both the
    mask and parameter tensors.
    """
    for name,module in model.named_modules():
        if isinstance(module, Attention_sp):# 找到head
            print("Attention_sp",name)
            for (nmask,mask),param in zip(name_masks(module),module.qkv.parameters(recurse=False)):
                if param is not module.qkv.bias:
                    #print("nmask",nmask)#head_mask 
                    yield nmask,mask ,param     
class Pruner:
    def __init__(self, masked_parameters):
        self.masked_parameters = list(masked_parameters)
        self.scores = {}

    def score(self, model, loss, dataloader, device):
        raise NotImplementedError

    def _global_mask(self, sparsity):
        r"""Updates masks of model with scores by sparsity level globally.
        """
        # # Set score for masked parameters to -inf 
        # for mask, param in self.masked_parameters:
        #     score = self.scores[id(param)]
        #     score[mask == 0.0] = -np.inf

        # Threshold scores
        global_scores = torch.cat([torch.flatten(v) for v in self.scores.values()])
        k = int((1.0 - sparsity) * global_scores.numel())
        if not k < 1:
            threshold, _ = torch.kthvalue(global_scores, k)##
            for mask, param in self.masked_parameters:
                score = self.scores[id(param)] 
                zero = torch.tensor([0.]).to(mask.device)
                one = torch.tensor([1.]).to(mask.device)
                mask.copy_(torch.where(score <= threshold, zero, one))
    def _head_mask(self, sparsity):
        r"""Updates masks of model with scores by sparsity level globally.
        """
        # # Set score for masked parameters to -inf 
        # for mask, param in self.masked_parameters:
        #     score = self.scores[id(param)]
        #     score[mask == 0.0] = -np.inf

        # Threshold scores

        least_s_idx = torch.topk(self.scores, 1, largest=False, sorted=False)# topk  k = 1  或者2 ，自己设置的
        print(least_s_idx)
        #for head_index in least_s_idx: uvc_layer.mask.data[:, head_index * minimax_model.head_size : (head_index + 1 ) * minimax_model.head_size] = 0


        global_scores = torch.cat([torch.flatten(v) for v in self.scores.values()])
        k = int((1.0 - sparsity) * global_scores.numel())
        if not k < 1:
            threshold, _ = torch.kthvalue(global_scores, k)
            ## 根据算出来的scores 和给入的rate获得阈值，其实也是获得一种策略，直接给如策略list应该也一样
            remain_indicator = [0,1,1,1,1,1,1,1,1,1,1,1]#,0,0,0,0 对每一个blocks的剪枝策略。
            #现在一个1/0代表64，我把列表放24位，那我一个粒度代表32，这样可以做出了可变长度的head剪枝？
            #generatingmask.py  的Sanity Pruning  先不用这个
            muti_head_dim = 64
            heads = 12
            atten_dim = muti_head_dim*heads

            atten_mask = {}


            for i,(nmask,mask ,param)  in enumerate(self.masked_parameters):
                attn_mask_name = str(i)+ nmask + '.qkv.weight_mask'
                print("param",param.size())
                atten_mask[attn_mask_name] = torch.zeros_like(param)
                for j,index_inside_layer in enumerate(remain_indicator):
                    if index_inside_layer:

                        q_start = j * muti_head_dim
                        k_start = q_start + atten_dim
                        v_start = k_start + atten_dim 
                        atten_mask[attn_mask_name][q_start: q_start + muti_head_dim, :] = 1.
                        atten_mask[attn_mask_name][k_start: k_start + muti_head_dim, :] = 1.
                        atten_mask[attn_mask_name][v_start: v_start + muti_head_dim, :] = 1.
                zero = torch.tensor([0.]).to(mask.device)
                one = torch.tensor([1.]).to(mask.device)
                attenmask = torch.tensor(atten_mask[attn_mask_name],dtype=torch.bool)
                mask.copy_(torch.where(attenmask, one, zero))
            print("!!!!!!!!!!!!",atten_mask.keys())

            # for mask, param in self.masked_parameters:
            #     score = self.scores[id(param)] 
            #     zero = torch.tensor([0.]).to(mask.device)
            #     one = torch.tensor([1.]).to(mask.device)
            #     mask.copy_(torch.where(score <= threshold, zero, one))   
    def _local_mask(self, sparsity):
        r"""Updates masks of model with scores by sparsity level parameter-wise.
        """
        for mask, param in self.masked_parameters:
            score = self.scores[id(param)]
            k = int((1.0 - sparsity) * score.numel())
            if not k < 1:
                threshold, _ = torch.kthvalue(torch.flatten(score), k)##第k大的 值和索引
                zero = torch.tensor([0.]).to(mask.device)
                one = torch.tensor([1.]).to(mask.device)
                mask.copy_(torch.where(score <= threshold, zero, one))

    def mask(self, sparsity, scope):
        r"""Updates masks of model with scores by sparsity according to scope.
        """
        if scope == 'global':
            self._global_mask(sparsity)
        if scope == 'local':
            self._local_mask(sparsity)
        if scope == 'headcut':
            self._local_mask(sparsity)

    @torch.no_grad()
    def apply_mask(self):
        r"""Applies mask to prunable parameters.
        """
        for mask, param in self.masked_parameters:
            param.mul_(mask)

    def alpha_mask(self, alpha):
        r"""Set all masks to alpha in model.
        """
        for mask, _ in self.masked_parameters:
            mask.fill_(alpha)

    # Based on https://github.com/facebookresearch/open_lth/blob/master/utils/tensor_utils.py#L43
    def shuffle(self):
        for mask, param in self.masked_parameters:
            shape = mask.shape
            perm = torch.randperm(mask.nelement())
            mask = mask.reshape(-1)[perm].reshape(shape)

    def invert(self):
        for v in self.scores.values():
            v.div_(v**2)

    def stats(self):
        r"""Returns remaining and total number of prunable parameters.
        """
        remaining_params, total_params = 0, 0 
        for mask, _ in self.masked_parameters:
            remaining_params += mask.detach().cpu().numpy().sum()
            total_params += mask.numel()
        return remaining_params, total_params

class SynFlow(Pruner):
    def __init__(self, masked_parameters):
        super(SynFlow, self).__init__(masked_parameters)

    def score(self, model, loss, dataloader, device):

        @torch.no_grad()
        def linearize(model):
            # model.double()
            signs = {}
            for name, param in model.state_dict().items():
                signs[name] = torch.sign(param)
                param.abs_()
            return signs

        @torch.no_grad()
        def nonlinearize(model, signs):
            # model.float()
            for name, param in model.state_dict().items():
                param.mul_(signs[name])
        
        signs = linearize(model)

        (data, _) = next(iter(dataloader))
        input_dim = list(data[0,:].shape)
        input = torch.ones([1] + input_dim).to(device)#, dtype=torch.float64).to(device)
        output = model(input)
        torch.sum(output).backward()
        
        for _, p in self.masked_parameters:
            self.scores[id(p)] = torch.clone(p.grad * p).detach().abs_()
            p.grad.data.zero_()

        nonlinearize(model, signs)

class Mag(Pruner):
    def __init__(self, masked_parameters):
        super(Mag, self).__init__(masked_parameters)
    
    def score(self, model, loss, dataloader, device):
        for _, p in self.masked_parameters:
            self.scores[id(p)] = torch.clone(p.data).detach().abs_()

def weight_list_to_scores(layer, head_size = None):
    #layer 应该是一个linear？ 就是atten里面的proj，等下就给你遍历出来，等着奥
    if 1:
        result_head_level = []
        num_heads = layer.in_features // head_size
        for i in range(num_heads):
            group_weight = layer.weight.data[:,i * head_size : (i + 1) * head_size]
            group_weight = group_weight.reshape(-1)
            result_head_level.append((group_weight ** 2).sum(0))
        return torch.tensor(result_head_level)


def prune_head_mask(minimax_model, optimizer=None):
    # lr = optimizer.param_groups[0]['lr']
    s = minimax_model.ceiled_s()
    # print("prune_head_mask s",s)
    for uvc_layer in minimax_model.uvc_layers["W1"]:
        # print("uvc_layer",uvc_layer)
        uvc_layer.mask.data[:] = 1
        layer_index, col = minimax_model.uvc_layers_dict["s_dict"][uvc_layer]
        # print("layer_index, col")
        # print(layer_index, col)
        scores2 = weight_list_to_scores(uvc_layer, layer_group_name="W1", head_size=minimax_model.head_size)
        # print("scores.size()")
        # print(scores1.size())
        # print(scores2)
        # for head_index in range(scores1.shape[0]):
        #     r_cur = r[layer_index,head_index]
        #     least_r_idx = torch.topk(scores1[head_index,:], int(r_cur.ceil().item()),largest=False, sorted=False)[1]
        #     uvc_layer.mask.data[:, least_r_idx + head_index * minimax_model.head_size] = 0

        least_s_idx = torch.topk(scores2, int(s[layer_index,col].ceil().item()), largest=False, sorted=False)[1]
        print(least_s_idx)
        for head_index in least_s_idx:
            uvc_layer.mask.data[:, head_index * minimax_model.head_size : (head_index + 1 ) * minimax_model.head_size] = 0

        

class ViTHead(Pruner):
    def __init__(self, masked_parameters):
        super(ViTHead, self).__init__(masked_parameters)
        self.masked_heads_layer = 1#head的qkv？# 自己加的layer 
    
    def score(self, model, loss, dataloader, device):
        for name, layer in self.masked_parameters:
            # 针对每一个head有一个score    self.masked_parameters是对每一位参数的，太细了 自己加一个
            self.scores[name] = weight_list_to_scores(self.masked_heads_layer, head_size = None)#uvs里面应该有，去抄代码/我自己也实现了一个哇1



class Taylor1ScorerAbs(Pruner):
    def __init__(self, masked_parameters):
        super(Taylor1ScorerAbs, self).__init__(masked_parameters)

    def score(self, model, loss, dataloader, device):

        for batch_idx, (data, target) in enumerate(dataloader):
            data, target = data.to(device), target.to(device)
            output = model(data)
            loss(output, target).backward()

        for _, p in self.masked_parameters:
            self.scores[id(p)] = torch.clone(p.grad * p).detach().abs_()
            p.grad.data.zero_()

def check_sparsity(model):

    sum_list = 0
    zero_sum = 0

    for name,m in model.named_modules():
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
            sum_list = sum_list+float(m.weight.nelement())
            zero_sum = zero_sum+float(torch.sum(m.weight == 0))  

    print('* remain weight = ', 100*(1-zero_sum/sum_list),'%')
    
    return 100*(1-zero_sum/sum_list)

def check_sparsity_dict(model_dict):

    sum_list = 0
    zero_sum = 0

    for key in model_dict.keys():
        if 'mask' in key:
            sum_list = sum_list+float(model_dict[key].nelement())
            zero_sum = zero_sum+float(torch.sum(model_dict[key] == 0))  

    print('* remain weight = ', 100*(1-zero_sum/sum_list),'%')
    
    return 100*(1-zero_sum/sum_list)

def prune_model_identity(model):

    print('start pruning with identity mask')
    for name,m in model.named_modules():
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
            print('identity pruning layer {}'.format(name))
            prune.Identity.apply(m, 'weight')

def prune_model_custom(model, mask_dict):

    print('start pruning with custom mask')
    for name,m in model.named_modules():
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
            print('custom pruning layer {}'.format(name))
            prune.CustomFromMask.apply(m, 'weight', mask=mask_dict[name+'.weight_mask'])

def extract_mask(model_dict):

    new_dict = {}

    for key in model_dict.keys():
        if 'mask' in key:
            new_dict[key] = copy.deepcopy(model_dict[key])

    return new_dict

def prune_conv_linear(model):

    for name, module in reversed(model._modules.items()):

        if len(list(module.children())) > 0:
            model._modules[name] = prune_conv_linear(model=module)

        if isinstance(module, nn.Linear):
            bias=True
            if module.bias == None:
                bias=False
            layer_new = Linear(module.in_features, module.out_features, bias)
            model._modules[name] = layer_new

        if isinstance(module, nn.Conv2d):
            layer_new = Conv2d(module.in_channels, module.out_channels, module.kernel_size, module.stride)
            model._modules[name] = layer_new

    return model


