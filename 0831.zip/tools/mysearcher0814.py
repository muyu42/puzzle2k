import argparse
import copy
import hashlib
import itertools
import json
import random
import time
from abc import ABC, abstractmethod
from collections import defaultdict
from contextlib import contextmanager, redirect_stderr, redirect_stdout
from os import devnull
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import torch
import tqdm
from torch import nn
import torch.distributed as dist

import timm



@contextmanager
def suppress_stdout_stderr():
    """A context manager that redirects stdout and stderr to devnull"""
    with open(devnull, "w") as fnull:
        with redirect_stderr(fnull), redirect_stdout(open(devnull, "w")):
            yield
'''
这段代码定义了一个名为suppress_stdout_stderr的上下文管理器（context manager），用于临时重定向标准输出（stdout）和标准错误（stderr）到/dev/null（一个特殊的设备文件，会丢弃所有写入的数据）。

首先，它使用了Python的contextmanager装饰器，使得这个函数可以作为一个上下文管理器使用。在使用上下文管理器时，yield语句之前的部分将在进入上下文前执行，而yield语句之后的部分将在退出上下文后执行。

在进入上下文之前，代码打开了/dev/null文件用于写入，以及用于错误重定向的fnull文件。open(devnull, "w")打开了一个以只写模式打开的/dev/null文件。redirect_stderr(fnull)和redirect_stdout(open(devnull, "w"))使用了contextlib模块中的redirect_stderr()和redirect_stdout()函数，分别将标准错误和标准输出重定向到fnull文件。

在退出上下文之后，文件会自动关闭。

总之，当你使用suppress_stdout_stderr上下文管理器包装某段代码时，该代码块中所有的标准输出和标准错误将会被重定向到/dev/null，即被完全忽略。这在需要临时禁止输出时非常有用。

'''




def cuda_time() -> float:
    torch.cuda.synchronize()
    return time.perf_counter()


def num2hrb(num: float, suffix="", base=1000) -> str:
    """Convert big floating number to human readable string."""
    for unit in ["", "K", "M", "G", "T"]:
        if abs(num) < base:
            return f"{num:3.2f}{unit}{suffix}"
        num /= base
    return f"{num:.2f}{suffix}"


def stats(vals: List[float]) -> Dict[str, float]:
    """Compute min, max, avg, std of vals."""
    STATS = {"min": np.min, "max": np.max, "avg": np.mean, "std": np.std}
    return {name: fn(vals) for name, fn in STATS.items()} if vals else {}


class BaseSearcher(ABC):
    iter_num: int
    num_satisfied: int
    candidate: Dict[str, Any]
    best: Dict[str, Any]
    samples: Dict[str, Any]
    history: Dict[str, Any]

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        for key, val in self.default_state_dict.items():
            setattr(self, key, copy.deepcopy(val))

    def search(
        self,
        model: nn.Module,
        num_iters: int,
        filter_func,
        score_func: Callable[[nn.Module], float],
        save_func: Optional[Callable[[Dict[str, Any]], None]] = None,
        verbose: bool = True,
    ) -> Dict[str, Any]:
        # initialize search
        self.model = model
        # construct constraints checker function from constraints dict
        self.filter_func = filter_func
        self.score_func = score_func
        self.save_func = save_func

        if verbose:
            pbar = tqdm.trange(
                self.iter_num,
                num_iters,
                initial=self.iter_num,
                total=num_iters,
                position=0,
                leave=True,
            )

        # run initial step and sanity checks before search step
        self.before_search()

        for self.iter_num in range(self.iter_num, num_iters):
            self.before_step()
            self.run_step()
            self.after_step()

            if verbose:
                info = {
                    "num_satisfied": self.num_satisfied,
                    "metric": self.candidate["metric"],
                    "constraints": self.candidate["constraints"],
                    "best_subnet_metric": self.best["metric"],
                    "best_subnet_constraints": self.best["constraints"],
                }

                # display the full stats only once a while
                if len(self.history["metric"]) == 100:
                    info["metric/stats"] = stats(self.history["metric"])
                    info["constraints/stats"] = {
                        name: stats(vals)
                        for name, vals in self.history["constraints"].items()
                    }
                    self.history["metric"].clear()
                    self.history["constraints"].clear()

                def _recursive_format(obj, fmt):
                    if isinstance(obj, float):
                        return num2hrb(obj)
                    if isinstance(obj, dict):
                        return {k: _recursive_format(v, fmt) for k, v in obj.items()}
                    return obj

                pbar.update()
                info = _recursive_format(info, fmt="{:.4g}")
                print("".join(f"\n+ [{k}] = {v}" for k, v in info.items()) + "\n")

            if self.early_stop():
                break

        if verbose:
            pbar.close()
            print(
                f'[best_subnet_metric] = {info["best_subnet_metric"]} \
                    [best_subnet_constraints] = {info["best_subnet_constraints"]}'
            )

        return self.best

    def _sample(self) -> Dict[str, Any]:
        return {
            "config": sample(self.model),
        }

    @abstractmethod
    def sample(self) -> Dict[str, Any]:
        """Sample and select new sub-net configuration and return configuration."""
        raise NotImplementedError

    def before_search(self) -> None:
        pass

    def before_step(self) -> None:
        pass

    def run_step(self) -> None:
        # sample and select the candidate
        self.candidate = self.sample()

        # obtain the active config and hparams
        config = self.candidate["config"]

        # serialize and hash the candidate
        buffer = json.dumps({"config": config}, sort_keys=True)
        ckey = hashlib.sha256(buffer.encode()).hexdigest()

        if ckey not in self.samples:
            # check constraints
            (
                self.candidate["is_satisfied"],
                self.candidate["constraints"],
            ) = self.filter_func(self.model)

            # evaluate the metric
            if self.candidate["is_satisfied"]:
                self.candidate["metric"] = float(self.score_func(self.model))
            else:
                self.candidate["metric"] = -float("inf")

            self.samples[ckey] = copy.deepcopy(self.candidate)
        else:
            self.candidate = copy.deepcopy(self.samples[ckey])
        rank, _ = get_dist_info()
        if rank == 0:
            with open('evolve_search.txt', 'a+') as f:
                f.write(str(self.iter_num) + ' ' + str(self.candidate["metric"]))
                f.write('\n')

        self.num_satisfied += int(self.candidate["is_satisfied"])
        self.candidate["is_best"] = (
            self.candidate["metric"] >= self.best["metric"] or self.iter_num == 0
        )

        # update the stats if satisfied
        if self.candidate["is_satisfied"]:
            self.history["metric"].append(self.candidate["metric"])
            for name, val in self.candidate["constraints"].items():
                self.history["constraints"][name].append(val)

        # update the best if necessary
        if self.candidate["is_best"]:
            self.best = copy.deepcopy(self.candidate)
            best_res = self.candidate['metric']
            best_latency = self.candidate["constraints"]
            best_cfg = self.candidate["config"]
            if dist.is_master():
                with open(self.search_log, 'a+') as f:
                    f.write(str(self.iter_num) + ' ' + str(best_res) + ' ' + str(best_latency))
                    f.write('\n')
                    for k,v in best_cfg.items():
                        f.write(k+' '+str(v)+' ')
                    f.write('\n')

        # save the state dict
        if self.save_func is not None:
            self.save_func(self.state_dict())

    def after_step(self) -> None:
        pass

    def early_stop(self) -> bool:
        return False

    @property
    def default_state_dict(self) -> Dict[str, Any]:
        return {
            "iter_num": 0,
            "num_satisfied": 0,
            "candidate": {},
            "best": {"metric": -float("inf"), "constraints": None},
            "samples": {},
            "history": {"metric": [], "constraints": defaultdict(list)},
        }

    def state_dict(self) -> Dict[str, Any]:
        return {key: getattr(self, key) for key in self.default_state_dict}

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        for key in self.default_state_dict:
            setattr(self, key, state_dict[key])


class RandomSearcher(BaseSearcher):
    def sample(self) -> Dict[str, Any]:
        return self._sample()


class EvolveSearcher(BaseSearcher):
    population: List[Dict[str, Any]]
    candidates: List[Dict[str, Any]]

    def __init__(
        self,
        population_size: int = 100,
        candidate_size: int = 25,
        mutation_prob: float = 0.1,
        search_log: str = '',
    ) -> None:
        super().__init__()
        self.population_size = population_size
        self.candidate_size = candidate_size
        self.mutation_prob = mutation_prob
        self.search_log = search_log

    def sort_cfg(self, input: Dict[str, Any]) -> Dict[str, Any]:
        for var in input:
            stage_name = None
            p_ratios = []
            for name in input[var]:
                if name[-2] == '_':
                    stage_name = name[:-2]
                    p_ratios.append(input[var][name])
            p_ratios.sort()
            input[var][stage_name+'_1'] = p_ratios[0]
            input[var][stage_name+'_2'] = p_ratios[1]
            input[var][stage_name+'_3'] = p_ratios[2]
        return input

    def _mutate(self, input: Dict[str, Any]) -> Dict[str, Any]:
        output = self._sample()
        # only considers independent hparams
        output["config"] = config(self.model)
        for var in output:  # pylint: disable=C0206
            for name in output[var]:
                if random.random() > self.mutation_prob:
                    output[var][name] = input[var][name]
        output = self.sort_cfg(output)
        # returns reduced, independent config
        return output

    def _crossover(self, inputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        output = {"config": {}}
        # only considers independent hparams
        for name in config(self.model):
            output["config"][name] = random.choice(inputs)["config"][name]
        output = self.sort_cfg(output)
        # returns reduced, independent config
        return output

    def sample(self) -> Dict[str, Any]:
        if not self.candidates:
            return self._sample()
        if len(self.population) < self.population_size // 2:
            output = self._mutate(random.choice(self.candidates))
        else:
            output = self._crossover(random.sample(self.candidates, 2))
        # returns full config
        select(self.model, output["config"])
        output["config"] = config(self.model)
        return output

    def before_step(self) -> None:
        if len(self.population) >= self.population_size:
            self.candidates = sorted(
                self.population,
                key=lambda x: x["metric"],
                reverse=True,
            )[: self.candidate_size]
            self.population = []

    def after_step(self) -> None:
        if self.candidate["is_satisfied"]:
            self.population.append(copy.deepcopy(self.candidate))

    @property
    def default_state_dict(self) -> Dict[str, Any]:
        return {
            **super().default_state_dict,
            "population": [],
            "candidates": [],
        }


def recursive_eval(obj, globals=None):
    if globals is None:
        globals = copy.deepcopy(obj)

    if isinstance(obj, dict):
        for key in obj:
            obj[key] = recursive_eval(obj[key], globals)
    elif isinstance(obj, list):
        for k, val in enumerate(obj):
            obj[k] = recursive_eval(val, globals)
    elif isinstance(obj, str) and obj.startswith("${") and obj.endswith("}"):
        obj = eval(obj[2:-1], globals)
        obj = recursive_eval(obj, globals)

    return obj


def select0(model: nn.Module, configs: Dict[str, Any]) -> None:
    #总体来说，这段代码根据给定的配置字典，为模型中的不同模块设置剪枝比率。对于深度为2的模块，为所有的pruning_ratios赋相同的配置值。
    # 对于深度为6的模块，根据配置字典中的不同键名，提取并排序相关值，并将这些值添加到pruning_ratios列表中，以确保剪枝比率在适当的位置重复出现。
    for name, module in model.named_modules():#遍历模型的所有模块，获取每个模块的名称和实例
        if isinstance(module, SwinBlockSequence):
            if module.depth == 2:
                module.pruning_ratios = [configs[name], configs[name]]
            elif module.depth == 6:
                p_ratios = [configs[name+'_1'], configs[name+'_2'], configs[name+'_3']]
                assert p_ratios[0] <= p_ratios[1] and p_ratios[1] <= p_ratios[2]
                module.pruning_ratios = []
                for i in range(3):
                    module.pruning_ratios.append(p_ratios[i])
                    module.pruning_ratios.append(p_ratios[i])
def select(model: nn.Module, configs: Dict[str, Any]) -> None:
    for name, module in model.named_modules():
        if isinstance(module, nn.Sequential):#如果是resnet的conv层，如果是vit的   
            for i in range(len(module)):
                module[i].pruning_ratios = configs["block"+str(i)]

def sample0(model: nn.Module, sample_func: Optional[Callable] = None) -> Dict[str, Any]:#用于对给定的模型进行采样和配置选择。
    if sample_func is None:
        sample_func = random.choice#如果没有传递采样函数，则使用random.choice作为默认的采样函数

    # TODO: move this choices to the module
    choices = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]#定义了一个包含一系选择项的列表。这些选择项的值可以在采样函数中选择并应用于模型的不同模块。

    configs = {}
    for name, module in model.named_modules():
        if isinstance(module, SwinBlockSequence):
            if module.depth == 2:
                configs[name] = sample_func(choices)
            elif module.depth == 6:
                p_ratios = [sample_func(choices) for i in range(3)]
                p_ratios.sort()
                configs[name + '_1'] = p_ratios[0]
                configs[name + '_2'] = p_ratios[1]
                configs[name + '_3'] = p_ratios[2]
            else:
                raise Exception('wrong stage depth')
    select(model, configs)
    return configs
def sample(model: nn.Module, sample_func: Optional[Callable] = None) -> Dict[str, Any]:#用于对给定的模型进行采样和配置选择。
    if sample_func is None:
        sample_func = random.choice#如果没有传递采样函数，则使用random.choice作为默认的采样函数

    # TODO: move this choices to the module
    choices = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]#定义了一个包含一系选择项的列表。这些选择项的值可以在采样函数中选择并应用于模型的不同模块。

    configs = {}
    for name, module in model.named_modules():
        if isinstance(module, nn.Sequential):#如果是resnet的conv层，如果是vit的   
            for i in range(len(module)):

                configs["block"+str(i)] = sample_func(choices)

    select(model, configs)
    return configs

def config0(model: nn.Module) -> Dict[str, Any]:
    configs = {}
    for name, module in model.named_modules():
        if isinstance(module, SwinBlockSequence):
            if module.depth == 2:
                assert len(module.pruning_ratios) == 2 and module.pruning_ratios[0] == module.pruning_ratios[1]
                configs[name] = module.pruning_ratios[0]
            elif module.depth == 6:
                assert len(module.pruning_ratios) == 6
                configs[name+'_1'] = module.pruning_ratios[0]
                configs[name+'_2'] = module.pruning_ratios[2]
                configs[name+'_3'] = module.pruning_ratios[4]
    return configs
def config(model: nn.Module) -> Dict[str, Any]:
    configs = {}
    for name, module in model.named_modules():
        if isinstance(module, nn.Sequential):
            for i in range(len(module)):
                configs["block"+str(i)] = module[i].pruning_ratios
    return configs
from timm import utils
from collections import OrderedDict
from contextlib import suppress
import logging
##### Validation
import sys
import os
term_width = 80
term_width = int(term_width)

TOTAL_BAR_LENGTH = 65.
last_time = time.time()
begin_time = last_time
def progress_bar(current, total, msg=None):
    global last_time, begin_time
    if current == 0:
        begin_time = time.time()  # Reset for new bar.

    cur_len = int(TOTAL_BAR_LENGTH*current/total)
    rest_len = int(TOTAL_BAR_LENGTH - cur_len) - 1

    sys.stdout.write(' [')
    for i in range(cur_len):
        sys.stdout.write('=')
    sys.stdout.write('>')
    for i in range(rest_len):
        sys.stdout.write('.')
    sys.stdout.write(']')

    cur_time = time.time()
    step_time = cur_time - last_time
    last_time = cur_time
    tot_time = cur_time - begin_time

    L = []
    L.append('  Step: %s' % format_time(step_time))
    L.append(' | Tot: %s' % format_time(tot_time))
    if msg:
        L.append(' | ' + msg)

    msg = ''.join(L)
    sys.stdout.write(msg)
    for i in range(term_width-int(TOTAL_BAR_LENGTH)-len(msg)-3):
        sys.stdout.write(' ')

    # Go back to the center of the bar.
    for i in range(term_width-int(TOTAL_BAR_LENGTH/2)+2):
        sys.stdout.write('\b')
    sys.stdout.write(' %d/%d ' % (current+1, total))

    if current < total-1:
        sys.stdout.write('\r')
    else:
        sys.stdout.write('\n')
    sys.stdout.flush()

def format_time(seconds):
    days = int(seconds / 3600/24)
    seconds = seconds - days*3600*24
    hours = int(seconds / 3600)
    seconds = seconds - hours*3600
    minutes = int(seconds / 60)
    seconds = seconds - minutes*60
    secondsf = int(seconds)
    seconds = seconds - secondsf
    millis = int(seconds*1000)

    f = ''
    i = 1
    if days > 0:
        f += str(days) + 'D'
        i += 1
    if hours > 0 and i <= 2:
        f += str(hours) + 'h'
        i += 1
    if minutes > 0 and i <= 2:
        f += str(minutes) + 'm'
        i += 1
    if secondsf > 0 and i <= 2:
        f += str(secondsf) + 's'
        i += 1
    if millis > 0 and i <= 2:
        f += str(millis) + 'ms'
        i += 1
    if f == '':
        f = '0ms'
    return f
def validate(net,testloader,device,criterion,epoch=0):

    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = net(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            progress_bar(batch_idx, len(testloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
                % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))
    
    # Save checkpoint.
    acc = 100.*correct/total
    content = time.ctime() + ' ' + f'Epoch {epoch}, val loss: {test_loss:.5f}, acc: {(acc):.5f}'
    print(content)

    return test_loss,acc
def validate0(
        model,
        loader,
        loss_fn,
        device=torch.device('cuda'),
        amp_autocast=suppress,
        log_suffix=''
):
    batch_time_m = utils.AverageMeter()
    losses_m = utils.AverageMeter()
    top1_m = utils.AverageMeter()
    top5_m = utils.AverageMeter()

    model.eval()

    end = time.time()
    last_idx = len(loader) - 1
    with torch.no_grad():
        for batch_idx, (input, target) in enumerate(loader):
            last_batch = batch_idx == last_idx
            if 1:
                input = input.to(device)
                target = target.to(device)

            with amp_autocast():
                output = model(input)
                if isinstance(output, (tuple, list)):
                    output = output[0]

                loss = loss_fn(output, target)
            acc1, acc5 = utils.accuracy(output, target, topk=(1, 5))

            reduced_loss = loss.data

            if device.type == 'cuda':
                torch.cuda.synchronize()

            losses_m.update(reduced_loss.item(), input.size(0))
            top1_m.update(acc1.item(), output.size(0))
            top5_m.update(acc5.item(), output.size(0))

            batch_time_m.update(time.time() - end)
            end = time.time()

    metrics = OrderedDict([('loss', losses_m.avg), ('top1', top1_m.avg), ('top5', top5_m.avg)])

    return metrics

def main():

    # import modules from string list.
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    

    # build the dataloader
    dataset_train = timm.data.create_dataset("torch/CIFAR10","/homeB/liangxiaoyu/dataset/cifar10/",download=True,split="train")
    dataset_val = timm.data.create_dataset("torch/CIFAR10","/homeB/liangxiaoyu/dataset/cifar10/",download=True,split="val")
    im_size = 224
    if 1:
        im_size = 384

    data_loader_train = timm.data.create_loader(
        dataset_train,(3, im_size, im_size), 4
    )
    data_loader_val = timm.data.create_loader(
        dataset_val,(3, im_size, im_size), 4
    )
    validate_loss_fn = nn.CrossEntropyLoss().to(device=device)


    # build the model and load checkpoint
    model = timm.create_model("vit_base_patch16_384", pretrained=False)
    model.head = nn.Linear(model.head.in_features, 10)
    model = model.to(device=device)
    #print(model)
    print("####"*10)




    if 1:
        # Load checkpoint.
        print('==> Resuming from checkpoint-epoch35-acc0.96 checkpoint..')   
        checkpoint = torch.load("/homeB/liangxiaoyu/23w0322/vitcifartrainnas/newversion/vision-transformers-cifar10-main/checkpoint-epoch35-acc0.96/vit_timm-4-ckpt.t7")
        #print(checkpoint['model'].keys())#去掉'module.
        def dropmodule(s):
            return s[7:]
        #print(list(map(dropmodule,checkpoint['model'])))
        a = {k[7:]:v for k,v in checkpoint['model'].items() }
        model.load_state_dict(a)
        print('######Resuming from checkpoint-epoch35-acc0.96 checkpoint..')   

    #exit()
    random.seed(0)

    def evaluate(model: nn.Module) -> float:
        eval_metrics = validate(
                model,
                data_loader_val,
                device,
                validate_loss_fn,
            )
        return eval_metrics[1]
    
    #0831 插入pruner
    # eval_metrics = evaluate(model)
    # print(eval_metrics)##测试结束   96.20000-[0,1,0,0,1,0,1,1,0,0,1,1]--95.15

    from my_pruning_utils import vitheadPruner
    #import pruning_utils
    # 替换模型atten为sp-atten
    from layers import Attention_Headmask,Attention_sp
    from timm.models.vision_transformer import Attention

    def prune_head_linear(model):# 替换模型中的atten子模型--深度优先搜索（DFS）的遍历方式
        for name, module in reversed(model._modules.items()):
            if len(list(module.children())) > 0:
                model._modules[name] = prune_head_linear(model=module)
                #print("!!!n",name)
            if isinstance(module, Attention):#z0831 找的是继承关系，同名的不行  from vision_transformer import Attention不行
                #print("0831")
                layer_new = Attention_sp( dim= 768, num_heads=12, qkv_bias=True, qk_scale=None, attn_drop=0., proj_drop=0.)
                model._modules[name] = layer_new
                #print("!!!!!trans",name)
        return model
    #print(model)
    prune_head_linear(model)

    model.load_state_dict(a, strict=False)
    model.cuda()
    pruner = vitheadPruner(model)
    model.train()
    print("pruner.scores1",pruner.scores)
    pruner.head_proj_mag_score( 64)

    print("pruner.scores2",pruner.scores)
    #exit()
    print("pruner.strategy1",pruner.strategy)
    pruner.score_to_list()

    #pruner.strategy["0proj_mask"] = []

    print("pruner.strategy2",pruner.strategy)
    #exit()
    pruner.mask_by_list(64)

    pruner.mask_apply()









    eval_metrics = evaluate(model)
    print(eval_metrics)##测试结束
    exit()


    @torch.inference_mode()#一个装饰器，将函数体内的所有代码在推理模式下执行。推理模式是为了优化模型的推理性能而做的设置，可以关闭一些只在训练时需要的功能，从而提高推理的速度。
    def measure(model, num_repeats=300, num_warmup=200, img_size=im_size):
        model.eval()#将模型设置为评估模式

        
        inputs = torch.randn(4, 3, img_size, img_size).cuda()#模拟推理过程中的输入数据

        latencies = []#空列表，用于存储后续的推理延迟时间。
        for k in range(num_repeats + num_warmup):
            start = cuda_time()#记录当前时间作为开始时间
            model(inputs)#对输入数据进行推理，计算模型的输出
            if k >= num_warmup:  #在num_warmup次迭代之后开始收集推理延迟时间
                latencies.append((cuda_time() - start) * 1000)  #计算推理的时间差，并将其乘以1000，以毫秒为单位。

        #latencies = itertools.chain(dist.allgather(latencies))#！！！！列表中的推理延迟时间收集到所有的计算设备上，这通常用于多GPU或分布式推理设置中
        latencies = sorted(latencies)#列表按照从小到大的顺序进行排序

        drop = int(len(latencies) * 0.25)
        return np.mean(latencies[drop:-drop])#计算需要丢弃的数据量，这里选择了排序后的延迟时间中的前后25%的数据进行丢弃。  然后取平均


    #exit()#0826
    # def filter_func(model):
    #     latency = measure(model)
    #     return args.min <= latency <= args.max, {"latency": latency}
    def filter_func(model):
        latency = measure(model)
        return 0 <= latency <= 1000, {"latency": latency}
    
    def save_func(state_dict):
        print(state_dict["best"])

    for sample_func in [min, lambda *_: 0.5]:#第一个元素是min函数，第二个元素是一个匿名函数，始终返回0.5 的函数
        print(sample_func, sample(model, sample_func))
        print("Latency: {:.2f} ms".format(measure(model)))
        print("Metric: {:.4f}".format(evaluate(model)))
    #!!!!!0826 在select函数具体实现剪枝代码，可以借用谷歌pruner或者之前自己的
    exit()
    search_log = 'work_dirs/search'+'.txt'
    searcher = EvolveSearcher(search_log=search_log,)
    searcher.search(
        model,
        num_iters=10000,
        filter_func=lambda model: filter_func(model),
        score_func=lambda model: evaluate(model),
        save_func=save_func,

    )


if __name__ == "__main__":
    main()